///> here 

console.log('simple-page.js');
